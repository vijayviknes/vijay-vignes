import java.util.*;

class Node {
    int data; 
    Node left, right;

    Node(int data) {
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

public class Main {

    static Node findLCA(Node root, int p, int q) {

        if (root == null) {
            return null;
        }

        if (root.data == p || root.data == q) {
            return root;
        }

        Node left = findLCA(root.left, p, q);
        Node right = findLCA(root.right, p, q);

        if (left != null && right != null) {
            return root;
        }

        return (left != null) ? left : right;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        HashMap<Integer, Node> map = new HashMap<>();
        HashSet<Integer> children = new HashSet<>();

        for (int i = 0; i < n; i++) {

            int parent = sc.nextInt();
            int left = sc.nextInt();
            int right = sc.nextInt();

            map.putIfAbsent(parent, new Node(parent));

            Node current = map.get(parent);

            if (left != -1) {
                map.putIfAbsent(left, new Node(left));
                current.left = map.get(left);
                children.add(left);
            }

            if (right != -1) {
                map.putIfAbsent(right, new Node(right));
                current.right = map.get(right);
                children.add(right);
            }
        }

        Node root = null;

        for (int id : map.keySet()) {
            if (!children.contains(id)) {
                root = map.get(id);
                break;
            }
        }

        int p = sc.nextInt();
        int q = sc.nextInt();

        Node lca = findLCA(root, p, q);

        if (lca != null) {
            System.out.println(lca.data);
        } else {
            System.out.println("LCA not found");
        }

        sc.close();
    }
}