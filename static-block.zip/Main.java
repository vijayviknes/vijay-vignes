/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
class Example{
    static int count;
    static {
        count=0;
        System.out.println("static members initialized");
    }
    Example(){
        count++;
    }
    static void disp(){
        System.out.print("count="+count);
    }
}
class Main
{
	public static void main(String[] args) {
		System.out.println("Driver class started");
		Example obj1=new Example();
		Example obj2=new Example();
		Example.disp();
	}
}