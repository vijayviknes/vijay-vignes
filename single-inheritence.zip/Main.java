/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
class A
{
    int a,b;
	public void getdata(){
		Scanner in=new Scanner(System.in);
		a=in.nextInt();
		b=in.nextInt();
	}
}
class Sum extends A{
    int c;
    public void sum(){
        c=a+b;
        System.out.print("Sum ="+c);
    }
}
class Main{
    public static void main(String[] args){
        Sum obj=new Sum();
        obj.getdata();
        obj.sum();
    }
    
}