/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;
import java.math.BigInteger;

public class Main {
    public static void main(String[] args) {

        Scanner il = new Scanner(System.in);

        System.out.print("Enter first 20-digit number: ");
        BigInteger num1 = il.nextBigInteger();

        System.out.print("Enter second 20-digit number: ");
        BigInteger num2 = il.nextBigInteger();

        BigInteger sum = num1.add(num2);

        System.out.println("Sum = " + sum);
    }
}