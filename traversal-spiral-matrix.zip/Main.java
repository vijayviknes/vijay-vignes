/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        System.out.println("Enter the n value:");
        int n = in.nextInt();

        int[][] mat = new int[n][n];

        System.out.println("Enter the matrix values:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mat[i][j] = in.nextInt();
            }
        } 
        List<Integer> result = new ArrayList<>();

        int top = 0;
        int bottom = n - 1;
        int left = 0;
        int right = n - 1;

        while (top <= bottom && left <= right) {


            for (int col = left; col <= right; col++) {
                result.add(mat[top][col]);
            }
            top++;

    
            for (int row = top; row <= bottom; row++) {
                result.add(mat[row][right]);
            }
            right--;

        
            if (top <= bottom) {
                for (int col = right; col >= left; col--) {
                    result.add(mat[bottom][col]);
                }
                bottom--;
            }

        
            if (left <= right) {
                for (int row = bottom; row >= top; row--) {
                    result.add(mat[row][left]);
                }
                left++;
            }
        }
        System.out.println("Spiral Traversal:");
        for (int val : result) {
            System.out.print(val + " ");
        }
    }
}
