import java.util.*;

public class Main {
    public static void main(String[] args) {

        Queue<Integer> q = new LinkedList<>();

        q.add(10);
        q.add(20);
        q.add(30);
        q.add(45);

        System.out.println(q);
        
        q.remove();

        System.out.println(q);

        System.out.println("Front Element: " + q.peek());
    }
}