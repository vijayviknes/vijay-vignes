/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int a=in.nextInt();
		int rev=0;
		while(a>0){
		    int rem=a%10;
		    rev=rem;
		    a=a/10;
		    System.out.print(rev);
		}
		
	}
}