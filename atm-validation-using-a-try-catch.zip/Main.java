import java.util.*;
public class Main
{
    public static void validation(int withdraw,int bal){
        if(withdraw<=bal){
            throw new ArithmeticException();
            }
            System.out.println("Insufficient balance");
    }
	public static void main(String[] args) {
		
		
		try{
		    validation(10000,150000);
		}
		catch(Exception e){
		    System.out.println("are you eligible to withdraw");
		}
	}
}
