/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
class A
{
	protected int a;
	A(int a){
	    this.a=a;
	}
}
class B extends A{
    int b;
    B(int a,int b){
       super(a);
       this.b=b;
    }
	   
}
class Sum{
    int cal;
    public void sum(B obj){
        cal=obj.a+obj.b;
        System.out.print("Sum of values are="+cal);
    }
    public static void main(String[] args){
        B obj1=new B(5,10);
        Sum obj2=new Sum();
        obj2.sum(obj1);
        
    }
}