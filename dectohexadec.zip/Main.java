/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.*;
public class Main{
    public static void main(String[] args) {
    Scanner in=new Scanner(System.in);
	System.out.println("Enter the decimal value:");
	int dec=in.nextInt();
	String hex=" ";
	while(dec>0){
	    int rem=dec%16;
		if(rem<10){
		    hex=rem+hex;
		    }
		else if(rem>=10){
		    hex=(char)((rem-10)+'A')+hex;
		       
		    }
		    
		    dec=dec/16;
		}
		System.out.println("converted hexadecimal value is:"+ hex);
	}
}