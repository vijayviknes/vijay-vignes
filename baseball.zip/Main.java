import java.util.*;

public class Main {

    public static int calPoints(String[] ops) {
        Stack<Integer> stack = new Stack<>();

        for (String op : ops) {

            if (op.equals("+")) {

                int first = stack.pop();
                int second = stack.peek();

                int sum = first + second;

                stack.push(first);
                stack.push(sum);

            } 
            else if (op.equals("D")) {

                stack.push(stack.peek() * 2);

            } 
            else if (op.equals("C")) {

                stack.pop();

            } 
            else {

                stack.push(Integer.parseInt(op));
            }
        }

        int total = 0;

        while (!stack.isEmpty()) {
            total += stack.pop();
        }

        return total;
    }

    public static void main(String[] args) {

        String[] ops = {"5", "2", "C", "D", "+"};

        System.out.println("Total Score = " + calPoints(ops));
    }
}