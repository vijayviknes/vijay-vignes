/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.*;
class Main {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int a,b;
        System.out.println("enter the 1 value:");
        a=in.nextInt();
        System.out.println("enter the 2 value:");
        b=in.nextInt();
        
        int sum=a+b;
        String hex1=" ";
        while(sum>0){
            int rem=sum%16;
            if(rem<10){
            hex1=rem+hex1;
            }
            else {
            hex1=(char)((rem-10)+'A')+hex1;
            
            
            }
            sum=sum/16;
        }
        System.out.println(hex1);
        
     
        

    }
}