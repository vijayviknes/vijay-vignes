
public class Main
{
	public static void nextGen(int[] arr) {
		for(int i=0;i<arr.length;i++){
		    int next=-1;
		    for(int j=i+1;j<arr.length;j++){
		        if(arr[j]>arr[i]){
		            next = arr[j];
		            break;
		        }
		        
		    }
		    System.out.println(next+" ");
		}
	}
	public static void main(String[] args){
	    int[] arr={12,1,10,15};
	    nextGen(arr);
	}
}