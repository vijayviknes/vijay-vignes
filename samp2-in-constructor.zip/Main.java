/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
class Example{
    static String college="HICET";
    String name;
    Example(String name){
        this.name=name;
    }
    public void disp(){
        System.out.print(name+"studies @"+college);
    }
}
class Main{
    public static void main(String[] args){
        Example pn=new Example("Ramya");
        pn.disp();
    }
}