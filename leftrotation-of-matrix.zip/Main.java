/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
        public static void rotation(int[] row, int k){
            int n=row.length;
            int[] temp=new int[k];
            for(int i=0;i<k;i++){
                temp[i]=row[i];
            }
            for(int i=k;i<n;i++){
                row[i-k]=row[i];
            }
            for(int i=0;i<k;i++){
                row[n-k+i]=temp[i];
            }
        }
        public static void main(String[] args) {
	    
	      Scanner in=new Scanner(System.in);
	      int row=in.nextInt();
	      int col=in.nextInt();
	    
	      int[][] mat=new int[row][col];
		  System.out.println("Enter the elements:");
		
		  for(int i=0;i<row;i++){
		    for(int j=0;j<col;j++){
		        mat[i][j]=in.nextInt();
		      }
	    	}
	    	System.out.println("Matrix is:");
          for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
          }
		  for (int i = 0; i < row; i++) {
             rotation(mat[i], i);   
          }
		  System.out.println("Matrix is:");
          for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
          }
        
        
		
	}
}