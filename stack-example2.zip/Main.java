import java.util.Stack;

public class Main {

    Stack<Integer> stack;
    Stack<Integer> minStack;

    // Constructor
    public Main() {
        stack = new Stack<>();
        minStack = new Stack<>();
    }

    // Push element
    public void push(int val) {
        stack.push(val);

        if (minStack.isEmpty()) {
            minStack.push(val);
        } else {
            minStack.push(Math.min(val, minStack.peek()));
        }
    }

    // Remove top element
    public void pop() {
        stack.pop();
        minStack.pop();
    }

    // Get top element
    public int top() {
        return stack.peek();
    }

    // Get minimum element
    public int getMin() {
        return minStack.peek();
    }

    public static void main(String[] args) {

        Main minStack = new Main();

        minStack.push(-2);
        minStack.push(0);
        minStack.push(-3);

        System.out.println("Minimum = " + minStack.getMin());

        minStack.pop();

        System.out.println("Top = " + minStack.top());

        System.out.println("Minimum = " + minStack.getMin());
    }
}