import java.util.*;
public class Main
{
    public static void validation(int mark){
        if(mark < 50){
            throw new ArithmeticException();
            }
            System.out.println("you are pass");
    }
	public static void main(String[] args) {
		
		
		try{
		    validation(55);
		}
		catch(Exception e){
		    System.out.println("are you blind");
		}
	}
}

