import java.util.*;
public class Main
{
	public static void main(String[] args) {
		int[] arr={25,15,14,25,16};
		int k=3;
		int sum=0;
		for(int i=0;i<k;i++){
		    sum += arr[i];
		}
		int maxSum = sum;
		int minSum = sum;
		for(int i=k;i<arr.length;i++){
		    sum = sum - arr[i-k] + arr[i];
		    maxSum = Math.max(maxSum, sum);
		    minSum = Math.min(minSum, sum);
		}
		System.out.println("Maximum Sum = "+maxSum);
		System.out.println("Maximum Sum = "+minSum);
		double avg = maxSum/k;
		System.out.printf("%.5f",(double)avg);
	}
}
