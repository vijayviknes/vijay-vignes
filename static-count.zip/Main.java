/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
class Examp{
    static int count=0;
    Examp(){
        count++;
    }
    public void disp(){
        System.out.print("objects created:"+count);
    }
}

public class Main
{
	public static void main(String[] args) {
		Examp in=new Examp();
		Examp on=new Examp();
		Examp to=new Examp();
		in.disp();
	}
}