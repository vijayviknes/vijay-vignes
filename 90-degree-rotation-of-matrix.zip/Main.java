/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner in=new Scanner(System.in);
	    System.out.println("Enter the no. of rows and cols: ");
	    int n=in.nextInt();
		int[][] mat=new int[n][n];
		System.out.println("Enter the values:");
		for(int i=0;i<n;i++){
		    for(int j=0;j<n;j++){
		        mat[i][j]=in.nextInt();
		    }
		}
		System.out.println("90 degree rotation:");
		for(int i=0;i<n;i++){
		    for(int j=n-1;j>=0;j--){
		        System.out.print(mat[j][i]+" ");
		    }
		    System.out.println(" ");
		}
	}
}